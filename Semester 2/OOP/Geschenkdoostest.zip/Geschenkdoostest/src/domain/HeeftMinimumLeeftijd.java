package domain;

public interface HeeftMinimumLeeftijd {
    int geefMinimumLeeftijd();
}
