import domain.Boek;
import org.junit.Before;
import org.junit.Test;
import static org.junit.Assert.assertEquals;

public class BoekTest {
    Boek boekje;
    @Before
    public void setUp(){
        boekje = new Boek(12, "Haasje Over", "Adolf H.",69 );
    }

    @Test
    public void Constructor_Test_Dat_Moest_absoluut_van_Mevr_Baerts_maar_ik_heb_daar_eigenlijk_niet_zo_veel_zin_in(){
        assertEquals("Haasje Over", boekje.getTitel());
        assertEquals("Adolf H.", boekje.getAuteur());
        assertEquals(12, boekje.getPrijs());
        assertEquals(69, boekje.getAantalPaginas());

        //Deze test kijkt alleen na of juist ingevoerde waarden een goed resultaat bekomen
        //Ik ga geen test schrijven die foute resultaten uitprobeert, want als u mijn andere
        // commentaren hebt gelezen weet u hoe dat zal aflopen
    }



}
